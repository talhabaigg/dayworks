<div class="container">
    
    <?php $__env->startSection('content'); ?>
        <h2>Daywork Order Details with Items</h2>

        <h3>Daywork Order Information</h3>
        <p><strong>Date:</strong> <?php echo e($dayworkOrder->daywork_order_date); ?></p>
        
        
        <p><strong>Reference Number:</strong> <?php echo e($dayworkOrder->daywork_ref_no); ?></p>
        <p><strong>Description:</strong> <?php echo e($dayworkOrder->description); ?></p>

        <h3>Daywork Order Items</h3>
        <?php if($dayworkOrder->items->count() > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Supplier Name</th>
                        <th>Quantity</th>
                        <th>Rate</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $dayworkOrder->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->supplier_name); ?></td>
                            <td><?php echo e($item->qty); ?></td>
                            <td><?php echo e($item->rate); ?></td>
                            <td><?php echo e($item->total); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No items found for this daywork order.</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\DayWorks\resources\views/showdaywork.blade.php ENDPATH**/ ?>