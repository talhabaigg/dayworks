
<?php $__env->startSection('content'); ?>
    <div class="container mx-auto my-2">
        <div class="flex flex-wrap">
            <div class="mx-auto max-w-7xl py-6 px-4 sm:px-6  sm:p-6 md:p-8 ">
                <div class="mb-4">
                    <div class="mb-2 flex justify-between">
                        <button
                            class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded inline-flex items-center">
                            <svg class="fill-current w-4 h-4 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                <path d="M13 8V2H7v6H2l8 8 8-8h-5zM0 18h20v2H0v-2z" />
                            </svg>
                            <span><a href="/daywork/order/<?php echo e($dayworkOrder->id); ?>/print">Download</a></span>
                        </button>
                        


                    </div>

                    <h1 class="text-sm font-semibold  bg-black text-white text-center p-1">VARIATION TO CONTRACT
                        #<?php echo e($dayworkOrder->id); ?></h1>
                    <div class="grid grid-cols-4 gap-2 divide-x divide-y border">
                        
                        <p class="p-1 text-xs sm:text-base md:text-m "><strong> DATE: </strong></p>
                        <p class="p-1 text-center text-xs sm:text-base md:text-m"> <?php echo e($dayworkOrder->daywork_order_date); ?>

                        </p>

                        <p class="p-1 text-xs sm:text-base md:text-m"><strong> PROJECT NAME: </strong></p>
                        <p class="p-1 text-center text-xs sm:text-base md:text-m"> <?php echo e($project->project_name); ?></p>


                        <p class="p-1 text-xs sm:text-base md:text-m"><strong> DAYWORK REF NO: </strong></p>
                        <p class="p-1 text-center text-xs sm:text-base md:text-m"> <?php echo e($dayworkOrder->daywork_ref_no); ?></p>
                        <p class="p-1 text-left text-xs sm:text-base md:text-m"><strong> ISSUED BY: </strong></p>
                        <p class="p-1 text-center text-xs sm:text-base md:text-m">
                            <?php echo e($user->first_name . ' ' . $user->last_name); ?></p>
                        <p class="p-1 text-left text-xs sm:text-base md:text-m"><strong> DESCRIPTION: </strong></p>
                        <p class="p-1 text-left text-xs sm:text-base md:text-m col-span-3"> <?php echo e($dayworkOrder->description); ?>

                        </p>
                    </div>

                    <h1 class="text-sm font-semibold  bg-black text-white text-center p-1">ITEMS</h1>

                    <div class="grid border grid-cols-7 gap-2 divide-x divide-y border">
                        <?php if($dayworkOrder->items->count() > 0): ?>
                            <table class="col-span-7 divide-x divide-y border">
                                <thead>
                                    <tr class="divide-x divide-y border text-center text-xs sm:text-base md:text-m">
                                        <th class="w-1/4">
                                            SUPPLIER NAME</th>
                                        <th class="w-1/4">ITEM CODE</th>
                                        <th class="w-auto"> QTY</th>
                                        <th class="w-auto">RATE</th>
                                        <th class="w-auto">TOTAL</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $dayworkOrder->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="divide-x divide-y border text-center">
                                            <td class="text-xs sm:text-base md:text-mn">
                                                <?php echo e($item->supplier_name); ?></td>
                                            <td class="text-left text-xs sm:text-base md:text-m">
                                                <?php echo e($item->item_code); ?></td>
                                            <td class="text-center text-xs sm:text-base md:text-m">
                                                <?php echo e(number_format($item->qty, 2)); ?></td>
                                            <td class="text-center text-xs sm:text-base md:text-m ">

                                                $<?php echo e(number_format($item->rate, 2)); ?>


                                            </td>
                                            <td class="text-center text-xs sm:text-base md:text-m">
                                                $<?php echo e(number_format($item->total, 2)); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            <?php else: ?>
                                <p>No items found for this daywork order.</p>
                        <?php endif; ?>
                        </table>
                    </div>
                    <div class="grid grid-cols-4 gap-2 text-sm">
                        <?php if($dayworkOrder->items->count() > 0): ?>
                            <?php
                                $totalSum = 0;
                            ?>



                            <?php $__currentLoopData = $dayworkOrder->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $totalSum += $item->total;
                                    $margin = $totalSum * 0.1;
                                    $totalCharge = $margin + $totalSum;
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <p class="col-span-3 ">Sub Total: </p>
                            <p class=" border-black col-span-1 pl-2 text-center"> <strong> $
                                    <?php echo e(number_format($totalSum, 2)); ?>

                                </strong>
                            </p>
                            <p class="col-span-3 ml-auto">Margin 10%: </p>
                            <p class="border-b border-black col-span-1 pl-2 text-center"> <strong> +$
                                    <?php echo e(number_format($margin, 2)); ?>

                                </strong>
                            </p>
                            <p class="col-span-3 ml-auto">Total: </p>
                            <p class="border-b border-black col-span-1 pl-2 text-center"> <strong>$
                                    <?php echo e(number_format($totalCharge, 2)); ?>

                                </strong>
                            </p>
                    </div>
                    <br>
                    <h1 class="text-sm font-semibold  bg-black text-white text-center p-1">LABOUR</h1>

                    <div class="grid border grid-cols-4 gap-2 divide-x divide-y border">
                        <?php if($dayworkOrder->labourItems->count() > 0): ?>
                            <table class="col-span-4 divide-x divide-y border">
                                <thead>
                                    <tr class="divide-x divide-y border text-center text-xs sm:text-base md:text-m">
                                        <th class="w-1/3">TYPE</th>
                                        <th class="w-1/5">DATE</th>
                                        <th class="text-center">QTY</th>
                                        <th class="text-center">RATE</th>
                                        <th class="text-center">TOTAL</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $dayworkOrder->labourItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="divide-x divide-y border text-center">
                                            <td class="text-xs sm:text-base md:text-m"><?php echo e($item->labour_name); ?>

                                            </td>
                                            <td class="text-xs sm:text-base md:text-m"><?php echo e($item->date); ?></td>
                                            <td class="text-xs sm:text-base md:text-m"><?php echo e($item->qty); ?></td>
                                            <td class="text-xs sm:text-base md:text-m">$
                                                <?php echo e(number_format($item->rate, 2)); ?>

                                            </td>
                                            <td class=" text-xs sm:text-base md:text-m">$
                                                <?php echo e(number_format($item->total, 2)); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            <?php else: ?>
                                <p>No items found for this daywork order.</p>
                        <?php endif; ?>
                        <?php endif; ?>
                        </table>
                    </div>
                    <div class="grid grid-cols-4 gap-2 text-sm">
                        <?php
                            $totalSum = 0;
                        ?>

                        <?php $__currentLoopData = $dayworkOrder->labourItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $totalSum += $item->total;
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <p class="col-span-3"><strong>Total: </strong></p>
                        <p class="border-b border-black col-span-1 pl-2 text-center"> <strong> $ <?php echo e($totalSum); ?>

                            </strong>
                        </p>
                    </div>
                    <?php if($dayworkOrder->labourItems->count() > 0): ?>
                        <div class="grid grid-cols-4 gap-2 text-sm">
                            <p class="col-span-3 ml-auto text-bold">TOTAL VARIATION: </p>
                            <?php
                                $totalVariation = $totalSum + $totalCharge;
                            ?>
                            <div class="bg-black text-white border border-black col-span-1 pl-2 text-center">
                                <p> <strong>$
                                        <?php echo e(number_format($totalVariation, 2)); ?>

                                    </strong>
                                </p>
                                <p class="ml-auto col-span-4 pl-2 text-center">
                                    ex GST

                                </p>
                            </div>
                        </div>
                    <?php endif; ?>
                    <br>
                    
                    <br>
                    <h1 class="text-sm font-semibold  bg-black text-white text-center p-1">ATTACHMENTS</h1>

                    <div class="border-t border-b grid grid-cols-2 gap-2 items-center justify-items-center">

                        <?php $__empty_1 = true; $__currentLoopData = $dayworkOrder->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <img class="border m-2 shadow col-span-2 rounded-lg shadow  "src="<?php echo e(Storage::url($item->file_path)); ?>"
                                alt="" style="max-height: 100px;">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>No attachments found for this daywork order.</p>
                        <?php endif; ?>

                    </div>

                </div>


            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\DayWorks\resources\views/loadDaywork.blade.php ENDPATH**/ ?>