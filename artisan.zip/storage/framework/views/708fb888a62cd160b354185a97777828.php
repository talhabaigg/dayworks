
<?php /**PATH C:\Laravel\DayWorks\resources\views/sidebar.blade.php ENDPATH**/ ?>