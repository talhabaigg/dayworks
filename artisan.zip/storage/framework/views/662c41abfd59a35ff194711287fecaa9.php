

<?php $__env->startSection('content'); ?>
    <div class="mx-auto max-w-7xl py-6 px-4 sm:px-6">
        <div class="mt-2 mx-3 flex items-center justify-between">
            <h1 class="text-4xl font-bold">PROJECTS</h1>
            <button class="bg-black hover:bg-blue-700 text-white font-bold py-2 px-4 border border-blue-700 rounded"><a
                    href="/create">ADD
                    PROJECT</a></button>
        </div>
        <div class="-mx-4 mt-8 overflow-x-scroll shadow ring-1 ring-black ring-opacity-5 sm:-mx-6 md:mx-0 md:rounded-lg">
            <table class="min-w-full divide-y divide-gray-300">
                <thead class="bg-gray-50">
                    <tr>
                        <th scope="col" class="px-8 py-3 ">Project Number</th>
                        <th scope="col" class="px-8 py-3 text-left">Project Name</th>
                        <th scope="col" class="px-8 py-3 text-left">Project Address</th>
                        <th scope="col" class="px-8 py-3 text-left">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr
                        class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                        <th class="px-6 py-3">
                            07-21-0035
                        </th>
                        <td class="px-6 py-4">
                            Reefview Hotel Lobby Refurbishment
                        </td>
                        <td class="px-6 py-4">
                            12 Resort Dr, Hamilton Island QLD 4803
                        </td>
                        <td class="px-6 py-4">
                            <button
                                class="bg-black hover:bg-blue-700 text-white font-bold py-1 px-2 border border-blue-700 rounded">
                                VIEW</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\DayWorks\resources\views/welcome.blade.php ENDPATH**/ ?>