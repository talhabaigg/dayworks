
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Create Daywork Order</h2>

        <form method="post" action="<?php echo e(route('daywork_orders.store')); ?>">
            <?php echo csrf_field(); ?>

            <label for="daywork_order_date">Daywork Order Date:</label>
            <input type="date" name="daywork_order_date" required>

            <label for="issued_by">Issued By:</label>
            <select name="issued_by" required>
                <!-- Populate the dropdown with users from your database -->
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <label for="project_id">Project:</label>
            <select name="project_id" required>
                <!-- Populate the dropdown with projects from your database -->
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <label for="daywork_ref_no">Daywork Reference Number:</label>
            <input type="text" name="daywork_ref_no" required>

            <label for="description">Description:</label>
            <textarea name="description" required></textarea>

            <h3>Daywork Order Items</h3>

            <!-- You can dynamically add more item fields using JavaScript if needed -->

            <label for="supplier_name">Supplier Name:</label>
            <input type="text" name="items[0][supplier_name]" required>

            <label for="item_code">Supplier Name:</label>
            <input type="text" name="items[0][item_code]" required>

            <label for="qty">Quantity:</label>
            <input type="number" name="items[0][qty]" required>

            <label for="rate">Rate:</label>
            <input type="number" step="0.01" name="items[0][rate]" required>

            <label for="total">Total:</label>
            <input type="number" step="0.01" name="items[0][total]" required>

            <button type="submit">Submit</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\DayWorks\resources\views/create.blade.php ENDPATH**/ ?>