<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            font-size: 10px;
            color: #333;
            /* Default text color */
        }



        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px auto;
            /* Center the table */
        }

        th {
            border: 1px solid #333;
            /* Dark border for table cells */
            padding: 2px;
            text-align: left;
        }

        .header th {
            background-color: #000;
            /* Black background for header cells */
            color: #fff;
            /* White text color for header cells */
        }

        td {
            border: 1px solid #333;
            /* Dark border for table cells */
            padding: 2px;
            text-align: left;
        }

        td.noborder {
            border: none;

            /* Add top border */
        }

        td.topborder {
            border-top: 1px solid #333;
            /* Add top border */
        }

        .signature {
            width: 200px;
            height: 75px;
        }
    </style>

    <title>New DayWorks</title>
</head>


<body>
    <img class = "signature" src="https://i.ibb.co/hRg9mPS/logo1.jpg" alt="">
    <h2>MATERIAL REQUISITION</h2>
    

    <div>
        <table>
            <tr>
                <th> DATE:</th>
                <td> </td>
                <th>DATE REQUIRED: </th>
                <td> <?php echo e($date); ?></td>
            </tr>
            <tr>
                <th> SUPPLIER:</th>
                <td> -</td>
                <th>JOB NO: </th>
                <td></td>
            </tr>
            <tr>
                <th> SITE REF NO:</th>
                <td></td>
                <th>JOB NAME: </th>
                <td></td>
            </tr>
        </table>
    </div>
    <br>

    <div>
        <table>
            <tr class ="header">
                <th>NOTES:</th>
            </tr>
            <tr>
                <td><?php echo e($notes); ?></td>
            </tr>
        </table>
    </div>
    <div>
        <table>
            <thead class ="header">
                <tr>

                    <th>Item Code</th>
                    <th style="width: 280px">Description</th>
                    <th style="width: 60px">Quantity</th>
                    <th style="width: 60px;">Rate</th>
                    <th style="width: 60px;">Total</th>
                    
                    <!-- Add other headers for line items as needed -->
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $lineItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                        <td><?php echo e($item['item_code']); ?></td>
                        <td><?php echo e($item['description']); ?></td>
                        <td><?php echo e(number_format($item['qty'], 2)); ?></td>
                        <td> $ <?php echo e(number_format($item['rate'], 2)); ?></td>
                        <td> $ <?php echo e(number_format($item['total'], 2)); ?></td>
                        
                        <!-- Display other line item fields as needed -->
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
                
                <!-- Display other line item fields as needed -->

            </tbody>


        </table>

    </div>

    
    
    <div>
        
        
    </div>
    </div>

</body>

</html>
<?php /**PATH C:\Laravel\DayWorks\resources\views/materialRequisitionOrder/template.blade.php ENDPATH**/ ?>